// The iPhone web player has been removed. This worker clears old caches, unregisters itself and sends open pages to the main site.
self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    const ks = await caches.keys(); await Promise.all(ks.map((k) => caches.delete(k)));
    await self.registration.unregister();
    const cs = await self.clients.matchAll({ type: "window" });
    cs.forEach((c) => { try { c.navigate("/"); } catch (x) {} });
  })());
});
